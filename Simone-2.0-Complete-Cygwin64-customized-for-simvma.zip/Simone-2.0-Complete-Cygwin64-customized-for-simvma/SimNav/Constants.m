%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SIMNAV - A GUI for Simone (Simulink Clone) Report Viewing
%
% Developed and Maintained by the NECSIS Model Pattern Project
%
% Developers:   Andrew Stevenson
%               Eric Rapos
%               Ron Elbaz
%               Melanie Wightman (Summer 2014)
%               Kenny Luc (Summer 2013)
%
% Last Updated: 15 July 2015
%
% Version Notes:
%   
%   Prior to Version 2.0, versions were identified by release date, however
%   features include:
%       - loading of csv report created from Simone report to display clone classes
%       - ability to open selected models (individually or as a clone class) and tile them on the screen
%       - ability to close all open models
%       - ability to deselect all selected models
%
%   Version 2.0 - Released 23 June 2015:
%       - added internal and external clone filtering
%       - added similarity threshhold filtering
%       - added visual version marker to Name field of SimNav, now users can see which version they are using
%       - updated tiling algorithm to better account for screen real-estate
%
%   Version 2.1 - Released 15 July 2015:
%       - added support for viewing of Stateflow clones
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%This class defines 2 constants used in the SimNav.m file.

classdef Constants
    properties (Constant = true)
        INT_CLONE = 1;
        EXT_CLONE = 2;
    end
end
