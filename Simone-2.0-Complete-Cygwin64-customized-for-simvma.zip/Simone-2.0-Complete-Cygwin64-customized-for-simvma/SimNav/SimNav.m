%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SIMNAV - A GUI for Simone (Simulink Clone) Report Viewing
%
% Developed and Maintained by the NECSIS Model Pattern Project
%
% Developers:   Andrew Stevenson
%               Eric Rapos
%               Ron Elbaz
%               Melanie Wightman (Summer 2014)
%               Kenny Luc (Summer 2013)
%
% Last Updated: 15 July 2015
%
% Version Notes:
%   
%   Prior to Version 2.0, versions were identified by release date, however
%   features include:
%       - loading of csv report created from Simone report to display clone classes
%       - ability to open selected models (individually or as a clone class) and tile them on the screen
%       - ability to close all open models
%       - ability to deselect all selected models
%
%   Version 2.0 - Released 23 June 2015:
%       - added internal and external clone filtering
%       - added similarity threshhold filtering
%       - added visual version marker to Name field of SimNav, now users can see which version they are using
%       - updated tiling algorithm to better account for screen real-estate
%
%   Version 2.1 - Released 15 July 2015:
%       - added support for viewing of Stateflow clones
%
%   Version 2.2 - Released 18 August 2015:
%       - bug fix: previous version could not handle if lass clone class was a singleton class
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Setting up SimNav interface
function varargout = SimNav(varargin) %varargout is the output, SimNav is the name, varargin is the input of the function.
% SIMNAV MATLAB code for SimNav.fig
%      SIMNAV, by itself, creates a new SIMNAV or raises the existing
%      singleton*.
%
%      H = SIMNAV returns the handle to a new SIMNAV or the handle to
%      the existing singleton*.
%
%      SIMNAV('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SIMNAV.M with the given input arguments.
%
%      SIMNAV('Property','Value',...) creates a new SIMNAV or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SimNav_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SimNav_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SimNav

% Last Modified by GUIDE v2.5 05-Mar-2015 12:07:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SimNav_OpeningFcn, ...
                   'gui_OutputFcn',  @SimNav_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
warning('off','MATLAB:str2func:invalidFunctionName');
if nargin && ischar(varargin{1}) %nargin returns the number of input args, ischar(a) returns true if 'a' is a char array.
    gui_State.gui_Callback = str2func(varargin{1}); %str2func(A) makes a function handle for the string A.
end

if nargout %returns number of function output
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:}); %unsure: create some sort of array for the output arg based on the state and the input arg
else
    gui_mainfcn(gui_State, varargin{:});%unsure: call the main function with the current state and input args for the program.
end

end
% End initialization code - DO NOT EDIT

% main figure creation function
% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles) %#ok
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

%hide known warnings

warning('off','Simulink:Engine:UnableToLoadBd');
warning('off','Simulink:Engine:MdlFileShadowedByFile');
warning('off','Simulink:LoadSave:FailedToCreateUDDObject');
warning('off','Simulink:Engine:ModuleLibraryLoadError');
warning('off','MATLAB:UndefinedFunction');
warning('off','MATLAB:MException:MultipleErrors');

end

% --- Executes just before SimNav is made visible.
function SimNav_OpeningFcn(hObject, eventdata, handles, varargin)%#ok
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SimNav (see VARARGIN)
global t;
t = timer('StartDelay',1);
t.TimerFcn = @(x,y)filterThreshold(hObject, eventdata, handles);
% Choose default command line output for SimNav
handles.output = hObject;

% Update handles structure
guidata(hObject, handles); %stores handles as GUI data, with the handle hObject.

if nargin == 4
    setTable(varargin{1}, handles.uitable1,handles);
    setDisplayVisible(handles);
    set(handles.uitable1, 'columnname', {'Clone Class', 'Similarity', 'Subsystem', 'Model File'});
end
end
% UIWAIT makes SimNav wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SimNav_OutputFcn(hObject, eventdata, handles) %#ok
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output; 
end

% --- Executes during object creation, after setting all properties.
function uitable1_CreateFcn(hObject, eventdata, handles)%#ok
% hObject    handle to uitable1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
end

% --- Executes when selected cell(s) is changed in uitable1.
% When a cell is selected, the row is highlighted yellow. If it is already
% highlighted it will deselect. Selecting a cell with a clone class will
% highlight the entire clone class.
function uitable1_CellSelectionCallback(hObject, eventdata, handles)%#ok
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
global CurrentData
global selected

if numel(eventdata.Indices) == 0 
    return;
end

rowIndex = eventdata.Indices(1);
colIndex = eventdata.Indices(2);
if (isempty(CurrentData{rowIndex,colIndex}))
    return;
end

jscroll = findjobj(handles.uitable1);
jtable = jscroll.getViewport.getComponent(0);
jtable.setSelectionBackground(java.awt.Color.WHITE);
jtable.setSelectionForeground(java.awt.Color.BLACK);

switch colIndex
    case {3, 4}     % toggle individual row
        selected{rowIndex} = ~selected{rowIndex};       
        if selected{rowIndex}
            highlightRow(jtable, rowIndex);
        else
            unhighlightRow(jtable, rowIndex);
        end
    case {1, 2}     % toggle all rows in a clone class
        btnCloseAll_Callback(hObject, eventdata, handles);
        btnDeselectAll_Callback(hObject, eventdata, handles);
        selected{rowIndex} = ~selected{rowIndex};
        i = rowIndex;
        while i <= size(CurrentData, 1) && ~isempty(CurrentData{i, 3})
            selected{i} = selected{rowIndex};
            if selected{i}
                highlightRow(jtable, i);
            else
                unhighlightRow(jtable, i);
            end
            
            drawnow;
            i = i + 1;
        end
end

% Reposition selection to nearest blank cell
% (if clone class # row was clicked then cell right below,
%  otherwise leftmost column of current row)
% This is necessary because the click event will not register
% on a cell that you just selected, i.e. cannot select then
% immediately deselect a cell without this workaround
if ~strcmp(CurrentData{rowIndex, 1}, '')
    jtable.changeSelection(rowIndex, 0, false, false);
else
    jtable.changeSelection(rowIndex - 1, 0, false, false);
end
end

%helper function to highlight a row yellow when selected
function highlightRow(jtable, rowIndex)
global CurrentData
if ~strcmp(CurrentData{rowIndex, 3}, '')
    newSubsystemText = strcat('<html><font bgcolor=#F6DD14>', escapeHTML(CurrentData{rowIndex, 3}), '</font></html>');
    newModelFileText = strcat('<html><font bgcolor=#F6DD14>', escapeHTML(CurrentData{rowIndex, 4}), '</font></html>');
    jtable.setValueAt(newSubsystemText, rowIndex - 1, 2);
    jtable.setValueAt(newModelFileText, rowIndex - 1, 3);
end
end

%helper function to remove highlighting on a row when deselected
function unhighlightRow(jtable, rowIndex)
global CurrentData
if ~strcmp(CurrentData{rowIndex, 3},'')
    jtable.setValueAt(CurrentData{rowIndex, 3}, rowIndex - 1, 2);
    jtable.setValueAt(CurrentData{rowIndex, 4}, rowIndex - 1, 3);
end
end

%helper function to escape the special HTML characters
function S = escapeHTML(htmlStr)
S = strrep(htmlStr, '&', '&amp;');
S = strrep(S, '<', '&lt;');
S = strrep(S, '>', '&gt;');
end


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)%#ok
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figurePos = get(hObject, 'Position'); %get position property from hObject
width = figurePos(3);
height = figurePos(4);

set(handles.uitable1, 'Position', [0 0 width height-30]); %set the uitable1 position property relative to hObject
colWidth = get(handles.uitable1, 'ColumnWidth');
set(handles.uitable1, 'ColumnWidth',{colWidth{1},colWidth{2},(width-(colWidth{2}+colWidth{1}))/2,(width-(colWidth{2}+colWidth{1}))/2});


%resize items appropriately
repositionObject(handles.btnOpenSelected, 25, height);
repositionObject(handles.btnCloseAll, 25, height);
repositionObject(handles.btnDeselectAll(1), 25, height);
repositionObject(handles.btnLoad, 25, height);
repositionObject(handles.cloneTypeMenu, 22, height);
repositionObject(handles.lblCloneType, 20, height);
repositionObject(handles.lowerSlider, 25, height);
repositionObject(handles.lowerText, 25, height);
repositionObject(handles.upperSlider, 25, height);
repositionObject(handles.upperText, 25, height);
repositionObject(handles.lblSimilarity, 20, height);
repositionObject(handles.dash, 20, height);
% END resize----------------------------------------------------------------
end

% Helper function to easily reposition buttons
function repositionObject(object,adjustment,height)
objectPos = get(object,'Position');
objectPos(2) = height - adjustment;
set(object, 'Position', objectPos);
% end repositionobjects-----------------------------------------------------
end

%sets hidden objects to visible once a file has been selected.
function setDisplayVisible(handles)
set(handles.uitable1, 'visible','on');
set(handles.btnOpenSelected, 'visible','on');
set(handles.btnCloseAll, 'visible','on');
set(handles.btnDeselectAll, 'visible', 'on');
set(handles.cloneTypeMenu, 'visible', 'on');
set(handles.lblCloneType, 'visible', 'on');
set(handles.lowerSlider, 'visible', 'on');
set(handles.lowerText, 'visible', 'on');
set(handles.upperSlider, 'visible', 'on');
set(handles.upperText, 'visible', 'on');
set(handles.lblSimilarity, 'visible', 'on');
set(handles.dash, 'visible', 'on');
%end setVisible-------------------------------------------------------------
end

%sets the uitable based on which file has been selected.
function setTable(fileName, table, handles)
global CurrentData;
global BothTypes;
global InternalOnly;
global ExternalOnly;
global selected;
global SubsystemName;
fileID = fopen(fileName); %opens the .csv file
C = textscan(fileID, '%q%q%q%q','delimiter', ','); %scan for 4 strings, set the delimiter to ','
fclose(fileID); %close the file
C = flatten(C); %flattens to list
C = strrep(C, '"', ''); %removes " 
C = strrep(C, '&comma;', ',');

rows = size(C,1);

selected = cell(1,rows);
SubsystemName = cell(2,rows);
for i=1:size(selected,2)
    selected{i}=0;
end
BothTypes = C;
InternalOnly = cloneType(BothTypes,Constants.INT_CLONE);
ExternalOnly = cloneType(BothTypes,Constants.EXT_CLONE);


CurrentData = BothTypes;
set(table, 'data', CurrentData); %set the data property in hObject to C

%find the minimum value of similarity, and set the appropriate slider
%values based on it
minimumSimilarity = min(cell2mat(cellfun(@str2num,C(:,2),'UniformOutput',false)));
step = 1/(100-minimumSimilarity);
set(handles.lowerSlider,'Min',minimumSimilarity);
set(handles.lowerSlider,'Value',minimumSimilarity);
set(handles.upperSlider,'Min',minimumSimilarity);
set(handles.upperSlider,'Value',100);
set(handles.upperText,'String',100);
set(handles.lowerText,'String',minimumSimilarity);
set(handles.upperSlider,'SliderStep',[step step]);
set(handles.lowerSlider,'SliderStep',[step step]);
%end setTable--------------------------------------------------------------
end

%helper function to turn array into a list
function F = flatten(cellArray)
flattened = cellArray{1};
for i = 2:size(cellArray, 2);
    flattened = cat(2, flattened, cellArray{i});
end
F = flattened;
%end flatten---------------------------------------------------------------
end

%% Button Callbacks
% OPEN MODELS
function btnOpenSelected_Callback(hObject, eventdata, handles)%#ok
% hObject    handle to btnOpenSelected (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CurrentData;
global selected;
closeBlocks();

subsystemList = cell(0);
for i=1:size(selected,2);
    if (selected{i} == 1)
        modelFile = CurrentData(i, 4);
        if (~strcmp(modelFile, ''))
            load_system(modelFile{1});
            subsystemList{size(subsystemList,2)+1} = CurrentData(i,3);
        end
    end
end
openBlocks(subsystemList);
%END btnOpenSelected_Callback -------------------------------------------------
end

%Helper function to open the selected blocks.
function openBlocks(subsystemList)
global block_colors;
block_colors = [];

%This code is used to tile the models on the screen appropriatesly.
%For up to 12 models, the layout is specified, and beyond that an
%approximation using sqrt is used.
listSize = size(subsystemList,2);
screenSize = get(0,'ScreenSize');
if (listSize == 1) || (listSize == 2)
    gridSize = 2;
    width = screenSize(3)/2;
    height = (screenSize(4)-30)/1;
elseif (listSize == 3) || (listSize == 4)
    gridSize = 2;
    width = screenSize(3)/2;
    height = (screenSize(4)-30)/2;
elseif (listSize == 5) || (listSize == 6)
    gridSize = 3;
    width = screenSize(3)/3;
    height = (screenSize(4)-30)/2;
elseif (listSize == 7) || (listSize == 8) || (listSize == 9)
    gridSize = 3;
    width = screenSize(3)/3;
    height = (screenSize(4)-30)/3;
elseif (listSize == 10) || (listSize == 11) || (listSize == 12)
    gridSize = 4;
    width = screenSize(3)/4;
    height = (screenSize(4)-30)/3;
else
    gridSize = ceil(sqrt(listSize));
    width = screenSize(3)/gridSize;
    height = (screenSize(4)-30)/gridSize;
end;
row = 0;
col = 0;

for i=1:listSize;
    if (col == gridSize)
        col = 0;
        row = row + 1;
    end
    subsystemName = subsystemList{i}{1};
    subsystemPath = regexp(subsystemName,'\/','split');

    % new versions of matlab have tabbed view, so it is required to specify
    % a new window.
    verMATLAB = ver('MATLAB');
    curVer = str2double(verMATLAB.Version);
    if curVer >= 8.0
        open_system(subsystemName, 'window');
    else
        open_system(subsystemName);
    end;
    
    set_param(subsystemPath{1}, 'Lock', 'off');
    set_param(subsystemName, 'Location', [col*width,row*height, (col+1)*width, (row+1)*height]);
    set_param(subsystemPath{1}, 'ToolBar', 'off');
    set_param(subsystemName, 'StatusBar', 'off');
    set_param(subsystemName, 'ModelBrowserVisibility', 'off');
    set_param(subsystemName, 'ZoomFactor', 'FitSelection');
    
    col = col + 1;
    sys_paths = find_system(subsystemName, 'SearchDepth',1);
    for j = 1:size(sys_paths,1)
        try
            block_colors{i,j} = cell2mat(get_param(sys_paths(j), 'BackgroundColor')); %#ok
        catch exception %#ok
            %block_diagram does not have a parameter named 'BackgroundColor' 
        end
    end
end
%END openblocks------------------------------------------------------------
end 


% CLOSE MODELS
function btnCloseAll_Callback(hObject, eventdata, handles) %#ok
% hObject    handle to btnCloseAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closeBlocks();
%end close all-------------------------------------------------------------
end 

%Closes all opened blocks
function closeBlocks()
bdclose('all');
%END closeBlocks-----------------------------------------------------------
end

% DESELECT ALL SELECTED MODELS
function btnDeselectAll_Callback(hObject, eventdata, handles)%#ok
% hObject    handle to btnDeselectAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selected;
jscroll = findjobj(handles.uitable1);
jtable = jscroll.getViewport.getComponent(0);
for i = 1:size(selected, 2)
    if selected{i}
        unhighlightRow(jtable, i);
        selected{i} = false;
    end
    drawnow;
end
%end btnDeselectAll_Callback-----------------------------------------------
end


% --- Executes on button press in btnLoad.
function btnLoad_Callback(hObject, eventdata, handles)%#ok
% hObject    handle to btnLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.uitable1, 'Visible', 'off');
fileName = uigetfile('*.csv', 'Select SIMONE output file', 'simulinknav.csv');
if fileName == 0
    return;
end

%fill the table with the new report
setTable(fileName, handles.uitable1,handles);
setDisplayVisible(handles);
set(handles.uitable1, 'columnname', {'Clone Class', 'Similarity', 'Subsystem', 'Model File'});
end


%% chage the type of filter on clone types (internal, external or both)
% --- Executes on selection change in cloneTypeMenu.
function cloneTypeMenu_Callback(hObject, eventdata, handles)%#ok
% hObject    handle to cloneTypeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cloneTypeMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cloneTypeMenu
global CurrentData;

global BothTypes;
global InternalOnly;
global ExternalOnly;

str = get(hObject, 'String');
val = get(hObject,'Value');

%choose between 3 clone class options
switch str{val}
    case 'Internal & External'
        CurrentData = BothTypes;
    case 'Internal Only'
        CurrentData = InternalOnly;
    case 'External Only'
        CurrentData = ExternalOnly;
end

set(handles.uitable1, 'data', CurrentData);

global t;
stop(t);
filterThreshold(hObject, eventdata, handles);
end

% helper function for clone type filtering
function result=cloneType(Data, mode)
    
    result = {};
    
    modelfiles = Data(:,4);
    breaks = find(cellfun(@isempty,modelfiles));
    breaks = [0;breaks;size(modelfiles,1)];
    numClasses = size(breaks,1)-1;
    gap = {'','','',''};
    
    firstPlaced=0;
    
    for i=1:numClasses
        
        if i ~= numClasses
            tempClass = Data(breaks(i)+1:breaks(i+1)-1,1:4);
        else
            tempClass = Data(breaks(i)+1:end,1:4);
        end
        
        newClass = filter(tempClass,mode);
       
        if(firstPlaced==1 && ~isempty(newClass))
           result = [result;gap]; %#ok
        end
        if (~isempty(newClass))
            firstPlaced = 1;
        end
        result = [result;newClass];%#ok
        
    end;
end


% helper function for filtering
function newClass=filter(Data, mode)
    classID = Data(1,1);
    classSim = Data(1,2);
    files = Data(:,4);

    newClass = {};
    
    if(isequal(classID{1},'14'))
        disp('');
    end
    
    [un, idx_last, idx] = unique(files(:,1));%#ok
    unique_idx = accumarray(idx(:),(1:length(idx))',[],@(x) {sort(x)} );
    
    numUniqueVals = size(unique_idx,1);
    
    switch mode
        case Constants.INT_CLONE %internal clones
            rows = 1;
            for i=1:numUniqueVals
               if size(unique_idx{i},1) > 1
                  for j=1:size(unique_idx{i},1)
                      if j == 1
                          newClass(1,1) = classID;
                          newClass(1,2) = classSim;
                      end;
                      newClass(rows,3) = Data(unique_idx{i}(j),3);%#ok
                      newClass(rows,4) = Data(unique_idx{i}(j),4);%#ok
                      rows = rows+1;
                  end
               end
            end
            
            %newClass = Data;
            
        case Constants.EXT_CLONE %external clones
            if numUniqueVals ~=1
                newClass = Data;
            else
                newClass = {};
            end
    end;
            

end

% clone type menu creation
% --- Executes during object creation, after setting all properties.
function cloneTypeMenu_CreateFcn(hObject, eventdata, handles)%#ok
% hObject    handle to cloneTypeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end


%% the lower bound of the similarity threshhold
% --- Executes on slider movement.
function lowerSlider_Callback(hObject, eventdata, handles)%#ok
% hObject    handle to lowerSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%stop timer if button is pressed again
global t;
stop(t);

%adjust value appropriately
curVal = get(handles.lowerSlider,'Value');
upperVal = get(handles.upperSlider,'Value');

if curVal > upperVal
    curVal = upperVal;
    set(handles.lowerSlider,'Value',curVal);
end;
set(handles.lowerText, 'String', curVal);

%start timer for 1 second delay before updating display
start(t);
end


% --- Executes during object creation, after setting all properties.
function lowerSlider_CreateFcn(hObject, eventdata, handles)%#ok
% hObject    handle to lowerSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

end

% --- Executes during object creation, after setting all properties.
function lowerText_CreateFcn(hObject, eventdata, handles)%#ok
% hObject    handle to lowerText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% the upper bound of the similarity threshhold
% --- Executes on slider movement.
function upperSlider_Callback(hObject, eventdata, handles)%#ok
% hObject    handle to upperSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%stop timer if button is pressed again
global t;
stop(t);

%adjust value appropriately
curVal = get(handles.upperSlider,'Value');
lowerVal = get(handles.lowerSlider,'Value');
if curVal < lowerVal
    curVal = lowerVal;
    set(handles.upperSlider,'Value',curVal);
end;
set(handles.upperText, 'String', curVal);

%start timer for 1 second delay before updating display
start(t);

end

% --- Executes during object creation, after setting all properties.
function upperSlider_CreateFcn(hObject, eventdata, handles)%#ok
% hObject    handle to upperSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
end

% --- Executes during object creation, after setting all properties.
function upperText_CreateFcn(hObject, eventdata, handles)%#ok
% hObject    handle to upperText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% filter based on similarity threshhold
function filterThreshold(hObject, eventdata, handles)%#ok
global CurrentData;

lowerSim = get(handles.lowerSlider,'Value');
upperSim = get(handles.upperSlider,'Value');
cloneType = get(handles.cloneTypeMenu,'String');
cloneVal = get(handles.cloneTypeMenu,'Value');

global BothTypes;
global InternalOnly;
global ExternalOnly;

switch cloneType{cloneVal}
    case 'Internal & External'
        CurrentData = BothTypes;
    case 'Internal Only'
        CurrentData = InternalOnly;
    case 'External Only'
        CurrentData = ExternalOnly;
end

% END OF PASTE (SLIGHTLY MODIFIED) FROM cloneTypeMenu_Callback

% Get the number of rows
tableSize = size(CurrentData);
rows = tableSize(1);


%loop through all clone classes dealing with the header and discarding the
%body if necessary
deletedRows = 0;
currentRow = 1;
while currentRow <= rows-deletedRows
    %find the next row with a similarity value
    currentRow = getNextCloneClassHeaderRow(CurrentData, currentRow);
    if currentRow <= 0
        % getNextCloneClassHeaderRow() returns <= 0 when header not found
        break;
    end
    
    %invariant: currentRow is a header row with a similarity
    similarity = str2double(CurrentData{currentRow,2});
    
    %if it is a filtered value then delete until the next header row
    if (lowerSim <= similarity) && (similarity <= upperSim)
        %within bounds, move on to the next row
        currentRow = currentRow + 1;
    else
        % not within bounds
        % delete the current header row
        CurrentData(currentRow,:) = [];
        deletedRows = deletedRows + 1;
        % delete the body rows
        while currentRow <= (rows - deletedRows) && isHeaderRow(CurrentData,currentRow) == 0
            CurrentData(currentRow,:) = [];
            deletedRows = deletedRows + 1;
        end
        % do not increment currentRow
    end
end

%remove whitespace at end of table
if currentRow > rows-deletedRows
    CurrentData(currentRow-1,:) = [];
end

set(handles.uitable1, 'data', CurrentData);
end

% Helper Function for parsing table data
% returns the row number of the next line with a similarity
% output row will equal input row iff the input row is a class header
% return 0 if nothing found
function headerRow = getNextCloneClassHeaderRow(data, currentRow)
    headerRow = 0;
    %get the number of rows
    tableSize = size(data);
    rows = tableSize(1);
    
    while isHeaderRow(data, currentRow) == 0
        currentRow = currentRow + 1;
        if currentRow > rows
            %return 0 if no header is found by the end of data
            return;
        end
    end
    headerRow = currentRow;
end

% Determine if a row is a class header by checking if it has a
% similarity value
function TF = isHeaderRow(data, row)
    similarity = str2double(data{row,2});
    TF = ~isnan(similarity);
end
