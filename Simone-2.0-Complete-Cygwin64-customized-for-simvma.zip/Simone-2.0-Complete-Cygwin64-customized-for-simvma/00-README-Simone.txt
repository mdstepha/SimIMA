
SIMONE 2.0 Complete Cygwin64 (15 Feb 2016)
------------------------------------------
Software Technology Laboratory, Queen's University
May 2016

Copyright 2011-2016, M.H. Alafi, J.R. Cordy, T.R. Dean, M. Stephan, A. Stevenson


Installing SIMONE 
-----------------

SIMONE 2.0 Complete Cygwin64 is a complete pre-configured installation of the SIMONE 
Simulink clone detector version 2.0 for Mac OS X, Linux, and Cygwin64 under Windows 7/8/10.
All dependencies, including the NiCad 4.0 clone detector and the TXL programming 
language compiler 10.6d are included in the package and need not be separately installed.

To install SIMONE Complete Cygwin64, copy or move the distribution archive file
Simone-2.0-Complete-Cygwin64.tar.gz to your home directory, and issue the command:

	tar xvzf Simone-2.0-Complete-Cygwin64.tar.gz

This will unpack and create the SIMONE installation into the directory
Simone-2.0-Complete-Cygwin64 in your home directory.


Running SIMONE
--------------

To run SIMONE, change directory to the SIMONE installation directory and
use the command:

    ./simone simulink-system-name 

Where simulink-system-name is the root directory of the Simulink model sources
you want to analyze.  For example, to test your SIMONE installation, 
you can run the command:

    ./simone examples/automotive

to analyze the Simulink automotive example set included in the SIMONE distribution.

When SIMONE completes an analysis, the results will be in the file:

    simulink-system-name_systems-sort-clones-0.30-classes.csv

For example, the results of the test run above will be in:

     examples/automotive_systems-sort-clones-0.30-classes.csv

You can then use the SimNav interaface in Simulink to view and explore the results. 
See the SimNav manual for further information.


Changing SIMONE Parameters
--------------------------

A range of default configurations are built-in to SIMONE can be changed on the
command line.  In general, the SIMONE command allows for three parameters:

    ./simone [-blind] [-exact] [-difflimit NN%] simulink-model-system-folder

Where -blind allows for naming differences between matching model elements, 
whereas -exact insists that matching element names be the same.  The -difflimit
parameter specifies the level of similarity required for subsystems to be 
considered similar.  -difflimit NN% specifies that up to NN% of the elements,
lines, branches and attributes of matching subsystems may differ in similar subsystems.

By default, the ./simone command assumes -exact and -difflimit 30%.

SIMONE is also widely configurable to allow for a range of different analyses depending
on the application.  Configuration parameters are controlled by NiCad configuration
files in the subdirectory ./config in the SIMONE installation directory.

Several SIMONE configuration files are provided with the distribution, but users 
can create as many as they wish depending on their application.  The user can create 
his/her own configuration files by copying and modifying these files.  

While the SIMONE command line only allows for controlling the difference threshold
and blind renaming, there are several NiCad parameters that can be tuned in the SIMONE 
configuration files.  See the comments in the default ./config/simone30.cfg file 
for the complete set and their meanings.


Controlling Which Models to Analyze
-----------------------------------

Two of the most useful configuration parameters available are the "include=" iand "exclude="
parameters.  By default, SIMONE searches the Simulink system directory to be analyzed for
all Simulink ".mdl" files, and includes all of them in the analysis.

At times, Simulink systems under maintenance may contain temporary or test models that
should not be included in the analysis.  The "exclude=" configuration parameter can be
used to filtet these out. 

For example, to ignore all models whose file name or enclosing directory name include 
the words "test" or "Test", we can make a new configuration "simone-notest" by copying
the ./config/simone.cfg default configuration file to ./config/simone-notest.cfg, and
editing the new configuration to change the line:

	exclude=""
to:
	exclude= "[Tt]est"

Any bash shell file name pattern can be used to specify the files and directories 
to be excluded.

Similarly, we can limit the models to be analyzed to only those that match a particular
file name pattern.  For example, to limit the analysis to only those model files named
"Integration", we can make a new configuration "simone-intonly" by copying
the ./config/simone.cfg default configuration file to ./config/simone-intonly.cfg, and
editing the new configuration to change the line:

        include=""
to:
        include= "Integration"

When both "include=" and "exclude=" parameters are specified in a SIMONE configuration,
only those model files that match the inlcude pattern and do not match the exlude pattern
are processed.


Rebuilding SIMONE
-----------------

Should it ever be neccessary to modify or maintain the source code for the tools or 
TXL programs of SIMONE, you can rebuild SIMONE from source by changing directory to
the SIMONE installation directory and issuing the command:

    make

This will remove all previous binaries and recompile everything from source.


